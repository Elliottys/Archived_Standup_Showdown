This package contains third-party software components governed by the license(s) indicated below:
---------

Component Name: Autodesk FBX SDK  
License Type: FBX SDK License and Service Agreement  
Copyright (c) 2020 Autodesk, Inc.  All rights reserved.  

Use of the FBX SDK requires agreeing to and complying with the FBX SDK License and Service Agreement terms accessed at <https://unity3d.com/legal/autodesk-fbx> and copied below:

**Autodesk**

**LICENSE AND SERVICES AGREEMENT**

**Autodesk<sup>®</sup> FBX<sup>®</sup> SDK 2020**

**READ CAREFULLY:** AUTODESK LICENSES THE SOFTWARE AND OTHER LICENSED
MATERIALS ONLY ON THE CONDITION THAT LICENSEE ACCEPTS ALL OF THE TERMS
CONTAINED OR REFERENCED IN THIS AGREEMENT.

By selecting the “I accept” button or other button or mechanism designed
to acknowledge agreement to the terms of an electronic copy of this
Agreement, or by installing, downloading, accessing, or otherwise
copying or using all or any portion of the Autodesk Materials, (i) you
accept this Agreement on behalf of the entity for which you are
authorized to act (e.g., an employer) and acknowledge that such entity
is legally bound by this Agreement (and you agree to act in a manner
consistent with this Agreement) or, if there is no such entity for which
you are authorized to act, you accept this Agreement on behalf of
yourself as an individual and acknowledge that you are legally bound by
this Agreement, and (ii) you represent and warrant that you have the
right, power and authority to act on behalf of and bind such entity (if
any) or yourself. You may not accept this Agreement on behalf of another
entity unless you are an employee or other agent of such other entity
with the right, power and authority to act on behalf of such other
entity.

If Licensee is unwilling to accept this Agreement, or you do not have
the right, power and authority to act on behalf of and bind such entity
or yourself as an individual (if there is no such entity), (a) DO NOT
SELECT THE “I ACCEPT” BUTTON OR OTHERWISE CLICK ON ANY BUTTON OR OTHER
MECHANISM DESIGNED TO ACKNOWLEDGE AGREEMENT, AND DO NOT INSTALL,
DOWNLOAD, ACCESS, OR OTHERWISE COPY OR USE ALL OR ANY PORTION OF THE
AUTODESK MATERIALS; AND (b) WITHIN THIRTY (30) DAYS FROM THE DATE OF
ACQUIRING THE AUTODESK MATERIALS, LICENSEE MAY RETURN THE AUTODESK
MATERIALS (INCLUDING ANY COPIES) TO THE ENTITY FROM WHICH THEY WERE
ACQUIRED FOR A REFUND OF THE APPLICABLE LICENSE FEES PAID BY THE
LICENSEE.

The words “Autodesk", “Agreement” and “Licensee” and other capitalized
terms used in this Agreement are defined terms. The definitions can be
found in Exhibit A (if the terms are not defined in the main body of the
Agreement).

1\. **License**

1.1 <span class="underline">License Grant</span>. Subject to and
conditioned on Licensee’s continuous compliance with this Agreement,
Autodesk grants Licensee a nonexclusive, nonsublicensable,
nontransferable, limited license to Install and Access the Licensed SDK
and User Documentation, in each case solely (a) in the Territory, (b)
within the scope of the License Type and Permitted Number specified in
the applicable License Identification, and (c) in accordance with the
other terms of this Agreement, to:

1.1.1       (a)    use the SDK for development, research, internal,
educational, or commercial purposes:

(i) to create a software product with the capability to read and/or
write and/or translate Licensee files, which software product links to
the Library (“Developed Software”); and/or

(ii) to modify the Sample Code(s) solely to create an object code
version(s) (“Modified Code(s)”); and/or

(b)     reproduce the Library to link to the Developed Software.

1.1.2      (a)     incorporate the executable version of the Developed
Software into; and/or

(b)     incorporate the Modified Code(s) into; and/or

(c)     link the Library, in binary code form to;

software products developed by Licensee (“Licensee Product(s)”) for
Licensee’s Internal Business Needs.

1.1.3   reproduce, distribute and sublicense free of charge or for a
fee Licensee Product(s) provided that Licensee must sublicense the
Software, the Developed Software, the Library, the Sample Code(s) and
the Modified Code(s) “as is”, without warranty of any kind.

Various License Types are described in Exhibit B. In any case where
the License Identification does not specify a License Type or
Permitted Number or Territory, or there is no License Identification,
the License Type will, by default, be the Stand-alone (Individual)
License and the Territory will be worldwide, subject to the Export
Control requirements herein.

1.1.4       Licensee shall reproduce and apply any copyright or other
proprietary rights notices included on or embedded in the Software, or
any part thereof, to any copies of the Software or any part thereof,
or to the Developed Software, in any form.

1.1.5       Licensee shall place the following statement in the
copyright area of either: (i) the end-user License and/or terms of use
for the Developed Software; or (ii) the ‘About Box’ or similar notice
page of the Developed Software; and Licensee shall also include the
following statement in the copyright area of either: (a) the on-line
documentation regarding the Developed Software; or (b) any other
document related to Developed Software that contains copyright
information:

“This software contains Autodesk® FBX® code developed by Autodesk,
Inc. Copyright 2019 Autodesk, Inc. All rights, reserved. Such code is
provided “as is” and Autodesk, Inc. disclaims any and all warranties,
whether express or implied, including without limitation the implied
warranties of merchantability, fitness for a particular purpose or
non-infringement of third party rights. In no event shall Autodesk,
Inc. be liable for any direct, indirect, incidental, special,
exemplary, or consequential damages (including, but not limited to,
procurement of substitute goods or services; loss of use, data, or
profits; or business interruption) however caused and on any theory of
liability, whether in contract, strict liability, or tort (including
negligence or otherwise) arising in any way out of such code.”

1.2 <span class="underline">Upgrades and Previous Versions</span>.

1.2.1 <span class="underline">Effect of Upgrades</span>. If Autodesk or
a Reseller provides Licensee with an Upgrade to other Licensed Materials
previously licensed to Licensee, the Licensed Materials previously
licensed to Licensee and any other Autodesk Materials relating thereto
will thereafter be deemed to be a “Previous Version.” Except as set
forth in Section 1.2.2 (Exception for Relationship Program Licensees),
the license grant and other rights with respect to any Previous Version
will terminate one hundred twenty (120) days after Installation of the
Upgrade. Within such one hundred twenty (120) day period, except as set
forth in Section 1.2.2 (Exception for Relationship Program Licensees),
(a) Licensee must cease all use of any Previous Version and Uninstall
all copies of the Previous Version, and (b) upon expiration of such
period, such Previous Version will no longer constitute Licensed
Materials but rather will be deemed to be Excluded Materials and
Licensee will no longer have a license for any such Previous Version. At
Autodesk’s request, Licensee agrees to destroy or return to Autodesk or
the Reseller from which they were acquired all copies of the Previous
Version. Autodesk reserves the right to require Licensee to show
satisfactory proof that all copies of any Previous Version have been
Uninstalled and, if so requested by Autodesk, destroyed or returned to
Autodesk or the Reseller from which they were acquired.

1.2.2 <span class="underline">Exception for Relationship Program
Licensees</span>. The termination of rights as to Previous Versions
described in Section 1.2.1 (Effect of Upgrades) may not apply to
Licensee if and to the extent (a) Licensee participates in a
Relationship Program and the Relationship Program Terms authorize
Licensee to retain such Previous Versions or (b) otherwise authorized in
writing by Autodesk.

1.3 <span class="underline">Additional Terms</span>. The Licensed
Materials (or portions thereof) may be subject to terms (e.g., terms
accompanying such Licensed Materials or made available in connection
with ordering, installing, downloading, accessing, using or copying such
Licensed Materials) that are in addition to or different from the terms
set forth in this Agreement, and Licensee agrees to comply with such
terms.

1.4 <span class="underline">Other Materials</span>. If Autodesk provides
or makes available to Licensee any additional materials associated with
the Licensed Materials, including any corrections, patches, service
packs, updates or upgrades to, or new versions of, the Licensed
Materials (including Upgrades) or any Supplemental Materials or User
Documentation for the Licensed Materials, (a) such additional materials
may include or be subject to other terms in addition to or different
from the terms set forth in this Agreement (including, without
limitation, additional or different fees, license terms, or restrictions
on use), and Licensee agrees to comply with such terms, or (b) if there
are no other terms for such additional materials, they will (except as
otherwise provided by Section 1.2 (Upgrades and Previous Versions)) be
subject to the same terms (including, without limitation, the licenses,
applicable License Type and Permitted Number, and other terms of this
Agreement) as the Licensed Materials to which such additional materials
apply. In no event will the foregoing result in any rights with respect
to Excluded Materials.

1.5 <span class="underline">Authorized Users</span>. Licensee may permit
the Licensed Materials to be Installed and/or Accessed only by
Licensee’s Personnel (except as otherwise designated in the applicable
License Type), and any such Installation or Access will be subject to
any other requirements imposed by this Agreement and the applicable
License Type and Permitted Number. Licensee will be responsible for
compliance with this Agreement by Licensee’s Personnel and any other
persons who may have Access to the Autodesk Materials through Licensee
(whether or not such Access is authorized by Autodesk or within the
scope of the applicable License Type and Permitted Number).

1.6 <span class="underline">Third-Party Licensed Materials</span>. The
Autodesk Materials may contain or be accompanied by third-party
software, data or other materials that are subject to and provided in
accordance with terms that are in addition to or different from the
terms set forth in this Agreement. Such terms may be included or
referenced in or with such third-party software, data or other materials
(e.g., in the “About box”) or a web page specified by Autodesk (the URL
for which may be obtained on Autodesk’s website or on request to
Autodesk). Licensee agrees to comply with such terms. In addition,
Licensee will take sole responsibility for obtaining and complying with
any licenses that may be necessary to use third-party software, data or
other materials that Licensee uses or obtains for use in conjunction
with the Licensed Materials. Licensee acknowledges and agrees that
Autodesk has no responsibility for, and makes no representations or
warranties regarding, such third-party software, data or other materials
or Licensee’s use of such third-party software, data or other materials.

1.7 <span class="underline">Relationship Programs</span>. Autodesk may
offer to Licensee, and (if so) Licensee may participate in one (1) or
more Relationship Programs applicable to the Licensed Materials licensed
to Licensee under this Agreement (and such Relationship Programs may
include rights in addition to or different from those set forth in this
Agreement). Any Relationship Programs are subject to Autodesk’s terms
therefor, which terms are set forth in the applicable Relationship
Program Terms. Licensee agrees that if it requests, accepts, or makes
use of any Relationship Program, Licensee will be bound by such terms,
as they may be modified from time to time in accordance with the
applicable Relationship Program Terms (and such terms, as so modified
from time to time, are a part of and incorporated by reference into this
Agreement), and Licensee agrees to comply with such terms. Licensee
acknowledges that Autodesk may require a further acceptance of such
terms as a condition to participation in a Relationship Program.

1.8 <span class="underline">Services</span>. Autodesk may provide, and
Licensee may elect to receive or benefit from, certain Services from
time to time. Any Services are subject to Autodesk’s terms therefor,
which terms are set forth in the applicable Services Terms. Licensee
agrees that if it requests, accepts, or makes use of any Services,
Licensee will be bound by such terms, as they may be modified from time
to time in accordance with the applicable Services Terms (and such
terms, as so modified from time to time, are a part of and incorporated
by reference into this Agreement), and Licensee agrees to comply with
such terms. Licensee acknowledges that Autodesk may require a further
acceptance of such terms as a condition to providing Services.

1.9 <span class="underline">Archival Copy</span>. Licensee’s license
under Section 1.1 (License Grant) includes the right to make a single
archival copy of the Licensed Materials in the Territory, provided that
(a) the single-copy limitation will not apply to copies made as an
incidental part of a routine backup of Licensee’s entire computer system
on which the Licensed Materials are Installed in accordance with this
Agreement, where such backup includes the making of copies of
substantially all other software on such computer system and (b) any
archival copy may be Accessed or Installed (other than on a backup
storage medium from which the Licensed Materials cannot be Accessed)
only when and for so long as the primary copy of the Licensed Materials
is inaccessible and inoperable. Copies of the Licensed Materials that
are Installed and are in excess of the Permitted Number at any time
while the primary copy of the Licensed Materials is also Accessible are
not "archival copies" as permitted under this Section 1.9 (Archival
Copy).

1.10 <span class="underline">Nature of Licenses</span>. Licensee
acknowledges and agrees that when Licensee acquires a license of
Licensed Materials, (including through a Relationship Program or
Services), Licensee’s acquisition is neither contingent on the delivery
of any future features or functionality nor subject to any public or
other comments (oral, written or otherwise) made by Autodesk regarding
future features or functionality.

1.11 **Feedback**.

Licensee hereby grants Autodesk, under all of Licensee’s intellectual
property and proprietary rights, the following worldwide, exclusive,
transferable, perpetual, irrevocable, royalty-free, fully paid-up
rights: (1) to make, have made, use, copy, modify, and create derivative
works of the Feedback as part of or in connection with any Autodesk
product, technology, service, content, material, specification or
documentation (including without limitation in connection with the
marketing or sale thereof); (2) to publicly perform or display, import,
broadcast, transmit, distribute, license, offer to sell and sell, rent,
lease or lend copies of the Feedback (and derivative works thereof and
improvements thereon); and (3) to sublicense to third parties the
foregoing rights, including the right to sublicense to further third
parties. “<span class="underline">Feedback</span>” shall mean all
suggestions, comments, input, ideas, reports, information or know-how
(whether in oral or written form) provided by Licensee to Autodesk or an
Autodesk affiliate in connection with Licensee’s evaluation of or use of
the Licensed Materials. Feedback does not include any artwork or sample
content created by Licensee using the Licensed Materials.

2\. **License Limitations; Prohibitions**

2.1 <span class="underline">Limitations and Exclusions</span>.

2.1.1 <span class="underline">No License Granted; Unauthorized
Activities</span>. The parties acknowledge and agree that,
notwithstanding anything to the contrary in this Agreement, no license
is granted (whether expressly, by implication or otherwise) under this
Agreement (and this Agreement expressly excludes any right) (a) to
Excluded Materials, (b) to any Autodesk Materials that Licensee did not
acquire lawfully or that Licensee acquired in violation of or in a
manner inconsistent with this Agreement, (c) for Installation of or
Access to the Licensed Materials beyond the applicable license term
(whether a fixed term or Relationship Program period or term) or outside
the scope of the applicable License Type or Permitted Number, (d) for
Installation of the Licensed Materials on any Computer other than a
Computer owned or leased, and controlled, by Licensee, unless otherwise
authorized in writing by Autodesk, (e) to distribute, rent, loan, lease,
sell, sublicense, transfer or otherwise provide all or any portion of
the Autodesk Materials to any person or entity except as expressly set
forth in this Agreement or as expressly authorized in writing by
Autodesk, (f) to provide or make available any features or functionality
of the Autodesk Materials to any person or entity (other than to and for
Licensee itself for the purpose specified in the applicable License
Type), whether or not over a network and whether or not on a hosted
basis, (g) except as otherwise expressly provided with respect to a
specific License Type, to Install or Access or allow the Installation of
or Access to the Autodesk Materials over the Internet or other non-local
network, including, without limitation, use in connection with a wide
area network (WAN), virtual private network (VPN), virtualization, Web
hosting, time-sharing, service bureau, software as a service, cloud or
other service or technology, (h) to remove, alter or obscure any
proprietary notices, labels or marks in the Autodesk Materials, (i) to
decompile, disassemble or otherwise reverse engineer the Autodesk
Materials, or (j) to translate, adapt, arrange, or create derivative
works based on, or otherwise modify the Autodesk Materials for any
purpose.

2.1.2 <span class="underline">Licensed Materials as a Single
Product</span>. The Licensed Materials are licensed to Licensee as a
single product and the applicable components may not be separated for
Installation or Access (and all such components must be Installed and
Accessed on the same Computer except as authorized in writing by
Autodesk).

2.1.3 <span class="underline">Territory</span>. Except as otherwise
authorized in writing by Autodesk, the licenses granted in this
Agreement are granted only for the Territory. Nothing in this Agreement
permits Licensee (including, without limitation, Licensee’s Personnel,
if any) to Install or Access the Licensed Materials outside of the
Territory.

2.1.4 <span class="underline">Effect of Unauthorized Use</span>.
Licensee will not engage in, and will not permit or assist any third
party to engage in any of the uses or activities prohibited (or any uses
or activities inconsistent with the limitations described) in this
Section 2.1 (Limitations and Exclusions) (collectively, “Unauthorized
Uses”). Any such Unauthorized Use, and any Installation of or Access to
the Licensed Materials provided under this Agreement, outside of the
scope of the applicable license grants (including, without limitation,
outside the applicable License Type and/or Permitted Number) or
otherwise not in accordance with this Agreement, constitute or result in
infringement of Autodesk’s intellectual property rights as well as a
breach of this Agreement. Licensee will notify Autodesk promptly of any
such Unauthorized Uses or other unauthorized Installation or Access.

2.1.5 <span class="underline">Use of Open Source Software by
Licensee</span>.  If Licensee uses any third party software (including
free or Open Source Software), whether or not in conjunction with the
Software, Licensee shall ensure that its use does not: (i) create, or
purport to create, obligations of Autodesk or any of its affiliates with
respect to the Software; (ii) grant, or purport to grant, to any third
party any rights to or immunities under Autodesk’s or any of its
affiliates intellectual property rights; or (iii) cause the Software to
be subject to any licensing terms other than those set forth in this
Agreement.

2.2 <span class="underline">Circumvention</span>.

2.2.1 Licensee may not (i) utilize any equipment, device, software, or
other means to (or designed to) circumvent or remove any form of
technical protection used by Autodesk in connection with the Autodesk
Materials, or (ii) Install or Access the Autodesk Materials with any
product code, authorization code, serial number, or other
copy-protection device not supplied by Autodesk directly or through a
Reseller. Without limitation of the generality of the foregoing,
Licensee may not utilize any equipment, device, software, or other means
to (or designed to) circumvent or remove the Autodesk License Manager or
any tool or technical protection measure provided or made available by
Autodesk for managing, monitoring or controlling Installation of or
Access to Autodesk Materials.

2.2.2 Licensee may not utilize any equipment, device, software, or other
means to (or designed to) circumvent or remove any usage restrictions,
or to enable functionality disabled by Autodesk, in connection with the
Excluded Materials. Licensee may not bypass or delete any functionality
or technical limitations of the Autodesk Materials that (or that are
designed to) prevent or inhibit the unauthorized copying of,
Installation or Access to the Excluded Materials.

3\. **All Rights Reserved**

Autodesk and its licensors retain title to and ownership of, and all
other rights with respect to, the Autodesk Materials and all copies
thereof, including, without limitation, any related copyrights,
trademarks, trade secrets, patents, and other intellectual property
rights. Licensee has only the limited licenses granted with respect to
the Licensed Materials expressly set forth in this Agreement, and
Licensee has no other rights, implied or otherwise. Licensee
acknowledges and agrees that the Autodesk Materials are licensed, not
sold, and that rights to Install and Access the Licensed Materials are
acquired only under the license from Autodesk. The structure and
organization of Software included in the Autodesk Materials, any source
code or similar materials relating to such Software, any API Information
and Development Materials (both as described in Section 1.11 (APIs)),
and any other Licensed Materials identified as confidential or
proprietary are valuable trade secrets of, and confidential and
proprietary information of, Autodesk and its suppliers, and (a) may not
be distributed, disclosed or otherwise provided to third parties, and
(b) may be used only internally and only in conjunction with and for
Licensee’s own authorized internal use of the Licensed Materials.

4\. **Privacy; Use of Information; Connectivity**

4.1 <span class="underline">Privacy and Use of Information</span>.
Licensee acknowledges and agrees that Licensee (and third parties acting
on Licensee’s behalf) may provide, and Autodesk and its Resellers (and
third parties acting on behalf of Autodesk and its Resellers) may
obtain, certain information and data with respect to Licensee
(including, without limitation, personal information) and Licensee’s
business in connection with this Agreement, including, without
limitation, information and data provided to or obtained by Autodesk and
its Resellers (or third parties acting on behalf of Autodesk and its
Resellers) through the Customer Information Form and otherwise, in
connection with ordering, registration, activation, updating, validating
entitlement to, auditing, monitoring Installation of and Access to
Autodesk Materials, Relationship Programs and Services and managing the
relationship with Licensee. Licensee hereby consents to Autodesk
maintaining, using, storing and disclosing such information and data
(including, without limitation, personal information, if any) in
conformity with Autodesk’s policies on privacy and data protection, as
such policies may be updated from time to time, including without
limitation Autodesk’s Privacy Statement, as currently located at
[<span class="underline">http://usa.autodesk.com/privacy/</span>](http://usa.autodesk.com/privacy/).
Without limitation of the generality of the foregoing, Licensee
acknowledges and agrees that: (a) Autodesk may from time to time prompt
Licensee (and third parties acting on Licensee’s behalf) to provide
express agreement to the terms of Autodesk’s Privacy Statement and/or
express agreement to specific uses of information and data (including,
without limitation, personal information); (b) Autodesk may provide
information and data, including, without limitation, information and
data about Licensee’s use of Autodesk Materials, Relationship Programs,
and Licensee’s support requests, to Autodesk subsidiaries and
affiliates, Resellers and other third parties in connection with the
provision, maintenance, administration or usage of Licensed Materials,
Relationship Programs or Services or in connection with enforcement of
any agreements relating to Licensed Materials, Relationship Programs or
Services; and (c) Autodesk may make cross-border transfers of such
information and data, including to jurisdictions with privacy or data
protection laws that are less protective of Licensee than the
jurisdiction in which Licensee is domiciled. Licensee acknowledges and
agrees that such policies may be changed from time to time by Autodesk
and that, effective upon posting on Autodesk’s website or other written
notice from Autodesk, Licensee will be subject to such changes.

4.2 <span class="underline">Connectivity</span>. Certain Licensed
Materials may facilitate or require Licensee’s access to and use of
content and services that are hosted on websites maintained by Autodesk
or by third parties. In some cases, such content and services may appear
to be a feature or function within, or extension of, the Licensed
Materials on Licensee’s Computer even though hosted on such websites.
Accessing such content or services and use of Licensed Materials may
cause Licensee’s Computer, without additional notice, to connect
automatically to the Internet (transitorily, intermittently or on a
regular basis) and to communicate with an Autodesk or third-party
website—for example, for purposes of providing Licensee with additional
information, features and functionality or to validate that the Licensed
Materials and/or content or services are being used as permitted under
this Agreement or other applicable terms. Such connectivity to Autodesk
websites is governed by Autodesk’s policies on privacy and data
protection described in this Section 4 (Privacy; Use of Information;
Connectivity). Such connectivity to websites of third parties is
governed by the terms (including the disclaimers and notices) found on
such sites or otherwise associated with the third-party content or
services. Autodesk does not control, endorse, or accept responsibility
for any such third-party content or services, and any dealings between
Licensee and any third party in connection with such content or
services, including, without limitation, such third party’s privacy
policies, use of personal information, delivery of and payment for goods
and services, and any other terms associated with such dealings, are
solely between Licensee and such third party. Autodesk may at any time,
for any reason, modify or discontinue the availability of any
third-party content or services. Access to and use of certain content
and services (whether of Autodesk or third parties) may require assent
to separate terms and/or payment of additional fees.

5\. **Limited Warranty and Disclaimers**

5.1 <span class="underline">Limited Warranty</span>. Autodesk warrants
that, as of the date on which the Licensed Materials are delivered to
Licensee and for ninety (90) days thereafter or if the license term is
shorter, such shorter period (“Warranty Period”), the Licensed Materials
will provide the general features and functions described in the User
Documentation portion of the Licensed Materials. Autodesk's entire
liability and Licensee’s exclusive remedy during the Warranty Period
(“Limited Warranty”) will be, with the exception of any statutory
warranty or remedy that cannot be excluded or limited under law, at
Autodesk's option, (i) to attempt to correct or work around errors, if
any, or (ii) to refund the license fees, if any, paid by Licensee and
terminate this Agreement or the license specific to such Licensed
Materials. Such refund is subject to the return, during the Warranty
Period, of the Autodesk Materials, with a copy of Licensee’s License
Identification, to Licensee’s local Autodesk office or the Reseller from
which Licensee acquired the Autodesk Materials. THE LIMITED WARRANTY SET
FORTH IN THIS SECTION GIVES LICENSEE SPECIFIC LEGAL RIGHTS. LICENSEE MAY
HAVE ADDITIONAL LEGAL RIGHTS UNDER LAW WHICH VARY FROM JURISDICTION TO
JURISDICTION. AUTODESK DOES NOT SEEK TO LIMIT LICENSEE’S WARRANTY RIGHTS
TO ANY EXTENT NOT PERMITTED BY LAW.

5.2 <span class="underline">Disclaimer</span>. EXCEPT FOR THE EXPRESS
LIMITED WARRANTY PROVIDED IN SECTION 5.1 (LIMITED WARRANTY), AND TO THE
MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, AUTODESK AND ITS SUPPLIERS
MAKE, AND LICENSEE RECEIVES, NO WARRANTIES, REPRESENTATIONS, OR
CONDITIONS OF ANY KIND, EXPRESS OR IMPLIED (INCLUDING, WITHOUT
LIMITATION, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE, OR NONINFRINGEMENT, OR WARRANTIES OTHERWISE IMPLIED
BY STATUTE OR FROM A COURSE OF DEALING OR USAGE OF TRADE) WITH RESPECT
TO ANY AUTODESK MATERIALS, RELATIONSHIP PROGRAMS, OR SERVICES (PURSUANT
TO A RELATIONSHIP PROGRAM OR OTHERWISE). ANY STATEMENTS OR
REPRESENTATIONS ABOUT THE AUTODESK MATERIALS, RELATIONSHIP PROGRAMS OR
SERVICES AND THEIR FEATURES OR FUNCTIONALITY IN THE LICENSED MATERIALS
OR ANY COMMUNICATION WITH LICENSEE ARE FOR INFORMATION PURPOSES ONLY,
AND DO NOT CONSTITUTE A WARRANTY, REPRESENTATION, OR CONDITION. WITHOUT
LIMITING THE FOREGOING, AUTODESK DOES NOT WARRANT: (a) THAT THE
OPERATION OR OUTPUT OF THE LICENSED MATERIALS OR SERVICES WILL BE
UNINTERRUPTED, ERROR-FREE, SECURE, ACCURATE, RELIABLE, OR COMPLETE,
WHETHER OR NOT UNDER A RELATIONSHIP PROGRAM OR SUPPORT BY AUTODESK OR
ANY THIRD PARTY; (b) THAT ERRORS WILL BE CORRECTED BY AUTODESK OR ANY
THIRD PARTY; OR (c) THAT AUTODESK OR ANY THIRD PARTY WILL RESOLVE ANY
PARTICULAR SUPPORT REQUEST OR THAT SUCH RESOLUTION WILL MEET LICENSEE’S
REQUIREMENTS OR EXPECTATIONS. NOTHING IN THE FOREGOING RESTRICTS THE
EFFECT OF WARRANTIES OR CONDITIONS WHICH MAY BE IMPLIED BY LAW WHICH
CANNOT BE EXCLUDED, RESTRICTED OR MODIFIED NOTWITHSTANDING A CONTRACTUAL
RESTRICTION TO THE CONTRARY. WITHOUT LIMITING THE FOREGOING, Autodesk
AND ITS SUPPLIERS MAKE, AND LICENSEE RECEIVES, no warranties that: (I)
future versions of the SDK, Library and/or Sample Code(s), if any, will
contain features similar to or the same as the SDK, Library and/or
Sample Code(s), respectively or will be compatible with the SDK, Library
and/or Sample Code(s), respectively; (II) the Software or the SDK,
Library and/or Sample Code(s) will meet LICENSEE requirements; or (iii)
operation of the SDK, Library or Sample Code(s) will be uninterrupted or
error-free.

6\. **Warnings**

6.1 <span class="underline">Functionality Limitations</span>. The
Licensed Materials and Services (except for Licensed Materials designed
for non-commercial use, such as Autodesk Materials designed to be used
for household or other consumer purposes or licensed only for purposes
of educational or individual learning) are commercial professional tools
intended to be used by trained professionals only. Particularly in the
case of commercial professional use, the Licensed Materials and Services
are not a substitute for Licensee’s professional judgment or independent
testing. The Licensed Materials and Services are intended only to assist
Licensee with its design, analysis, simulation, estimation, testing
and/or other activities and are not a substitute for Licensee’s own
independent design, analysis, simulation, estimation, testing, and/or
other activities, including those with respect to product stress, safety
and utility. Due to the large variety of potential applications for the
Licensed Materials and Services, the Licensed Materials and Services
have not been tested in all situations under which they may be used.
Autodesk will not be liable in any manner whatsoever for the results
obtained through use of the Licensed Materials or Services. Persons
using the Licensed Materials or Services are responsible for the
supervision, management, and control of the Licensed Materials and
Services and the results of using the Licensed Materials and Services.
This responsibility includes, without limitation, the determination of
appropriate uses for the Licensed Materials and Services and the
selection of the Licensed Materials, Services and other computer
programs and materials to help achieve intended results. Persons using
the Licensed Materials or Services are also responsible for establishing
the adequacy of independent procedures for testing the reliability,
accuracy, completeness, and other characteristics of any output of the
Licensed Materials or Services, including, without limitation, all items
designed with the assistance of the Licensed Materials or Services.
Licensee further acknowledges and agrees that the Licensed Materials
form part of Licensee’s total unique hardware and software environment
to deliver specific functionality, and that the Licensed Materials and
Services provided by Autodesk may not achieve the results Licensee
desires within Licensee’s design, analysis, simulation, estimation,
and/or testing constraints.

6.2 <span class="underline">Activation Codes and Security</span>.

6.2.1 <span class="underline">Activation Code Required for
Installation/Access and Continued Use</span>. Installation of and Access
to the Licensed Materials require, and the continued use thereof may
from time to time require, activation codes issued by Autodesk.
Registration may be required before an activation code is issued by
Autodesk. Licensee will provide Autodesk and its Reseller with any
information required for such registration and agrees that any
information provided to Autodesk or its Reseller will be accurate and
current. Licensee will also maintain and update Licensee’s registration
information, on an ongoing basis, through customer data registration
processes, including without limitation the Customer Information Form,
which may be provided by Autodesk. Licensee acknowledges and agrees that
Autodesk may use such information in accordance with its Privacy
Statement (as described or referenced in Section 4 (Privacy; Use of
Information; Connectivity)).

6.2.2 <span class="underline">Disabling Access</span>. LICENSEE
ACKNOWLEDGES AND AGREES THAT INSTALLATION OF AND ACCESS TO LICENSED
MATERIALS MAY BE DISABLED BY THE ACTIVATION, SECURITY, AND TECHNICAL
PROTECTION MECHANISMS IF LICENSEE TRIES TO TRANSFER ALL OR A PART OF THE
LICENSED MATERIALS TO ANOTHER COMPUTER, IF LICENSEE TAMPERS WITH THE
TECHNICAL PROTECTION MECHANISMS OR DATE-SETTING MECHANISMS ON A COMPUTER
OR IN THE LICENSED MATERIALS, IF LICENSEE USES THE LICENSED MATERIALS
PAST AN APPLICABLE RELATIONSHIP PROGRAM PERIOD OR FIXED TERM, OR IF
LICENSEE UNDERTAKES CERTAIN OTHER ACTIONS THAT AFFECT THE SECURITY MODE
OR UNDER OTHER CIRCUMSTANCES AND THAT, IN ANY SUCH EVENT, LICENSEE’S
ACCESS TO LICENSEE’S WORK PRODUCT AND OTHER DATA MAY BE AFFECTED. MORE
INFORMATION IS CONTAINED IN THE APPLICABLE LICENSED MATERIALS OR
AVAILABLE FROM AUTODESK ON REQUEST.

6.2.3 <span class="underline">Effect of Activation Codes</span>.
Licensee acknowledges and agrees that receipt of an activation code
(whether or not provided to Licensee in error) will not constitute
evidence of or affect the scope of Licensee’s license rights. Those
rights will be only as set forth in this Agreement and the applicable
License Identification.

6.3 <span class="underline">Affected Data</span>. Work product and other
data created with Licensed Materials made available under certain
License Types, including licenses that limit the permitted purpose to
educational purposes or personal learning purposes, may contain certain
notices and limitations that make the work product and other data usable
only in certain circumstances (e.g., only in the education field). In
addition, if Licensee combines or links work product or other data
created with such Licensed Materials with work product or other data
otherwise created, then such other work product or data may also be
affected by these notices and limitations. Autodesk will have no
responsibility or liability whatsoever if Licensee combines or links
work product or other data created with such Licensed Materials with
work product or other data otherwise created. In addition, Licensee will
not remove, alter or obscure any such notices or limitations.

7\. **Limitations of Liability**

7.1 <span class="underline">Limitation on Type and Amount of
Liability</span>. IN NO EVENT WILL AUTODESK OR ITS SUPPLIERS HAVE ANY
LIABILITY (DIRECTLY OR INDIRECTLY) FOR ANY INCIDENTAL, SPECIAL,
INDIRECT, CONSEQUENTIAL OR PUNITIVE DAMAGES; FOR LOSS OF PROFITS, USE,
REVENUE, OR DATA; OR FOR BUSINESS INTERRUPTION (REGARDLESS OF THE LEGAL
THEORY FOR SEEKING SUCH DAMAGES OR OTHER LIABILITY). IN ADDITION, THE
LIABILITY OF AUTODESK AND ITS SUPPLIERS ARISING OUT OF OR RELATING TO
ANY AUTODESK MATERIALS, RELATIONSHIP PROGRAMS OR SERVICES WILL NOT
EXCEED THE AMOUNT PAID OR PAYABLE BY LICENSEE FOR SUCH AUTODESK
MATERIALS, RELATIONSHIP PROGRAMS, OR SERVICES, RESPECTIVELY.

7.2 <span class="underline">Application of and Basis for
Limitations</span>. THE LIMITATIONS OF LIABILITY IN THIS SECTION 7
(LIMITATIONS OF LIABILITY) WILL APPLY TO THE MAXIMUM EXTENT PERMITTED BY
APPLICABLE LAW TO ANY DAMAGES OR OTHER LIABILITY, HOWEVER CAUSED AND
REGARDLESS OF THE THEORY OF LIABILITY, WHETHER DERIVED FROM CONTRACT,
TORT (INCLUDING, WITHOUT LIMITATION, NEGLIGENCE) OR OTHERWISE, EVEN IF
AUTODESK HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH LIABILITY AND
REGARDLESS OF WHETHER THE LIMITED REMEDIES AVAILABLE HEREUNDER FAIL OF
THEIR ESSENTIAL PURPOSE. ALSO, LICENSEE AGREES THAT THE LICENSE,
RELATIONSHIP PROGRAMS AND SERVICES FEES AND OTHER FEES CHARGED BY
AUTODESK AND PAID BY LICENSEE ARE BASED ON AND REFLECTIVE OF THE
ALLOCATION OF RISK CONTEMPLATED BY THIS SECTION 7 (LIMITATIONS OF
LIABILITY) AND THAT THE LIABILITY LIMITATIONS IN THIS SECTION 7
(LIMITATIONS OF LIABILITY) ARE AN ESSENTIAL ELEMENT OF THE AGREEMENT
BETWEEN THE PARTIES.

8\. **Term and Termination**

8.1 <span class="underline">Term; Termination or Suspension</span>. Each
license under this Agreement, with respect to each specific set of
Licensed Materials covered by this Agreement, will become effective as
of the latest to occur of: (a) this Agreement becoming effective, (b)
payment by Licensee of the applicable fees, excluding licenses (such as
evaluation licenses) where no fees are required, (c) delivery of the
specific Licensed Materials, and (d) in the case of Autodesk Materials
provided in connection with a Relationship Program, upon commencement of
the applicable Relationship Program period or fixed term. Each of
Autodesk or Licensee may terminate this Agreement, Licensee’s license as
to Licensed Materials, Licensee’s Relationship Program, and/or the
provision of Services relating to the Licensed Materials if the other
party is in breach of this Agreement and fails to cure such breach
within ten (10) days after written notice of the breach; however, if
Licensee is in breach of Section 1 (License) or Section 2 (License
Limitations; Prohibitions), Autodesk may terminate this Agreement,
Licensee’s license as to Licensed Materials, Licensee’s Relationship
Program, and/or the provision of Services relating to the Licensed
Materials immediately upon written notice of the breach. In addition,
Autodesk may, as an alternative to termination, suspend Licensee’s
license as to the Licensed Materials, Licensee’s Relationship Program,
the provision of Services relating to the Licensed Materials, and/or
other Autodesk obligations or Licensee rights under this Agreement (or
under other terms, if any, relating to materials associated with the
Licensed Materials), if Licensee fails to make a payment to Autodesk or
a Reseller or otherwise fails to comply with the provisions of this
Agreement or other terms relating to any such license, Relationship
Program, Services, or other associated materials. Autodesk may also
terminate this Agreement if Licensee becomes subject to bankruptcy
proceedings, becomes insolvent, or makes an arrangement with Licensee’s
creditors. This Agreement will terminate automatically without further
notice or action by Autodesk if Licensee goes into liquidation.

Licensee acknowledges and agrees that Autodesk may assign or
sub-contract any of its rights or obligations under this Agreement.

8.2 <span class="underline">Effect of Termination of Agreement or
License</span>. Upon termination or expiration of this Agreement, the
licenses granted hereunder will terminate. Upon termination or
expiration of any license granted to Licensee, Licensee must cease all
use of Autodesk Materials to which such license applies, any
Relationship Program (including, without limitation, associated
services), and any Services and Uninstall all copies of the Autodesk
Materials. At Autodesk’s request, Licensee agrees to destroy or return
to Autodesk or the Reseller from which they were acquired all Autodesk
Materials. Autodesk reserves the right to require Licensee to show
satisfactory proof that all copies of the Autodesk Materials have been
Uninstalled and, if so requested by Autodesk, destroyed or returned to
Autodesk or the Reseller from which they were acquired. If Licensee’s
Relationship Program is terminated or expires, but this Agreement and
Licensee’s license to the Licensed Materials remains in effect, any
rights of Licensee based on the Relationship Program (including, without
limitation, rights with respect to Previous Versions) will terminate,
and (unless otherwise authorized by the Relationship Program Terms)
Licensee must comply with the obligations of Section 1.2.1 (Effect of
Upgrades) with respect to (including the obligations to cease use of,
Uninstall and destroy or return) all copies of such Previous Versions.

8.3 <span class="underline">Survival</span>. Sections 1.3 (Additional
Terms), 1.4 (Other Materials), 1.5 (Authorized Users), 1.6 (Third-Party
Licensed Materials), 1.11 (APIs), 2.1.1 (No License Granted;Unauthorized
Activities), 2.1.4 (Effect of Unauthorized Use), 2.2 (Circumvention), 3
(All Rights Reserved), 4 (Privacy; Use of Information; Connectivity),
5.2 (Disclaimer), 6 (Warnings), 7 (Limitations of Liability), 8 (Term
and Termination), and 9 (General Provisions) and Exhibit A will survive
any termination or expiration of this Agreement.

9\. **General Provisions**

9.1 <span class="underline">Notices</span>. Notices in connection with
this Agreement by either party will be in writing and will be sent by
electronic mail, postal service, or a delivery service (such as UPS,
FedEx or DHL), except that Licensee may not provide notice to Autodesk
of an Autodesk breach or provide notice of termination of this Agreement
by electronic mail. Notices from Autodesk to Licensee will be effective
(a) in the case of notices by email, one (1) day after sending to the
email address provided to Autodesk, or (b) in the case of notices by
mail or delivery service, five (5) days after sending by regular post or
delivery service to the address provided to Autodesk. Licensee hereby
consents to service of process being effected on Licensee by registered
mail sent to the address set forth on Licensee’s Customer Information
Form (or, if no Customer Information Form has been provided, Licensee’s
last address known by Autodesk) if so permitted by applicable law.
Notices from Licensee to Autodesk will be effective (a) in the case of
notices by email, one (1) day after sending to (and receipt by Autodesk
at) CopyrightAgent@autodesk.com, or (b) in the case of notices by mail
or delivery service, when received by Autodesk at Autodesk, Inc., 111
McInnis Parkway, San Rafael, California 94903, USA, Attention: Copyright
Agent. If Licensee participates in a Relationship Program, either party
may also provide notice as set forth in the Relationship Program Terms.

9.2 <span class="underline">Governing Law and Jurisdiction</span>. This
Agreement will be governed by and construed in accordance with the laws
of (a) Switzerland if Licensee acquired the Autodesk Materials in a
country in Europe, Africa or the Middle East, (b) Singapore if Licensee
acquired the Autodesk Materials in a country in Asia, Oceania or the
Asia-Pacific region, or (c) the State of California (and, to the extent
controlling, the federal laws of the United States) if Licensee acquired
the Autodesk Materials in a country in the Americas (including the
Caribbean) or any other country not specified in this Section 9.2
(Governing Law and Jurisdiction). The laws of such jurisdictions shall
govern without reference to the conflicts-of-laws rules thereof. The UN
Convention on Contracts for the International Sale of Goods and the
Uniform Computer Information Transaction Act shall not apply to (and are
excluded from the laws governing) this Agreement. In addition, each
party agrees that any claim, action or dispute arising under or relating
to this Agreement will be brought exclusively in (and the parties will
be subject to the exclusive jurisdiction of) the Superior Court of the
State of California, County of Marin, or the United States District
Court for the Northern District of California in San Francisco, except
that if Licensee has acquired the Autodesk Materials in (a) a country in
Europe, Africa or the Middle East, any such claim or dispute will be
brought exclusively in (and the parties will be subject to the exclusive
jurisdiction of) the courts of Switzerland, or (b) a country in Asia,
Oceania or the Asia-Pacific region, any such claim or dispute will be
brought exclusively in (and the parties will be subject to the exclusive
jurisdiction of) the courts of Singapore. Nothing in the foregoing will
prevent Autodesk from bringing an action for infringement of
intellectual property rights in any country where such infringement is
alleged to occur.

9.3 <span class="underline">No Assignment; Insolvency</span>. Licensee
may not assign this Agreement or any rights hereunder (whether by
purchase of stock or assets, merger, change of control, operation of
law, or otherwise) without Autodesk's prior written consent, which may
be withheld in Autodesk's sole and absolute discretion, and any
unauthorized purported assignment by Licensee will be void. In the
context of any bankruptcy or similar proceeding, Licensee acknowledges
and agrees this Agreement is and shall be treated as an executory
contract that may not be assumed and/or assigned without Autodesk's
prior written consent, which consent may be withheld in Autodesk's sole
and absolute discretion whether pursuant to Section 365(c)(1) of Title
11 of the United States Code or any other applicable law respecting the
treatment of executory contracts within bankruptcy. Any assignment
(regardless of how or on what basis the assignment may occur) will be
conditioned on compliance with the following: at least thirty (30) days
before assigning or agreeing to any assignment of rights under this
Agreement (including transferring any copies of or right to use the
Software), (a) Licensee must provide written notice to Autodesk,
Uninstall all copies of the Software, and (without limitation of the
generality of Section 9.7 (Audits)) allow Autodesk or its designee to
inspect the records, systems and facilities of (or operated for)
Licensee and its subsidiaries and affiliates to verify (by any means
available to Autodesk, whether remotely or on premises) that all copies
of the Software have been Uninstalled, (b) the proposed assignee must
agree to comply (and Licensee must ensure that the assignee will comply)
with all of the obligations of this Agreement with respect to such
Software, which agreement must provide that Autodesk is a third-party
beneficiary of the assignee’s agreement, and the assignee must provide a
copy of the agreement to Autodesk, and (c) Licensee and proposed
assignee must comply with all other transfer procedures identified by
Autodesk.

9.4 <span class="underline">Autodesk Subsidiaries and Affiliates</span>.
Licensee acknowledges and agrees that Autodesk may arrange to have its
subsidiaries and affiliates engage in activities in connection with this
Agreement, including, without limitation, delivering Autodesk Materials
and providing Relationship Programs and Services, provided that Autodesk
(and not such subsidiaries and affiliates) will remain subject to the
obligations of Autodesk under this Agreement. Licensee also agrees that
Autodesk’s subsidiaries and affiliates may enforce (including taking
actions for breach of) this Agreement.

9.5 <span class="underline">Exceptions to Prohibitions;
Severability</span>.

9.5.1 <span class="underline">Exceptions to Prohibitions</span>. The
prohibitions contained in this Agreement will not apply where and to the
extent applicable law does not allow such prohibitions to be enforced.
Licensee may have other rights under the laws of the state or country
within the Territory where the Licensed Materials are acquired, and this
Agreement does not change Licensee’s rights under the laws of such state
or country if and to the extent the laws of such state or country do not
permit this Agreement to do so. Licensee will bear the burden of proof
to demonstrate that applicable law does not allow (i) the enforcement of
such prohibitions; or (ii) this Agreement to change particular rights in
a state or country (and that Licensee has not exceeded the bounds of the
unenforceable prohibitions and unchangeable rights).

9.5.2 <span class="underline">Severability</span>. If and to the extent
any provision of this Agreement is held illegal, invalid, or
unenforceable in whole or in part under applicable law, such provision
or such portion thereof will be ineffective as to the jurisdiction in
which it is illegal, invalid, or unenforceable to the extent of its
illegality, invalidity, or unenforceability and will be deemed modified
to the extent necessary to conform to applicable law so as to give the
maximum effect to the intent of the parties. The illegality, invalidity,
or unenforceability of such provision in that jurisdiction will not in
any way affect the legality, validity, or enforceability of such
provision or any other provision of this Agreement in any other
jurisdiction.

9.6 <span class="underline">No Waiver</span>. No term or provision of
this Agreement will be considered waived, and no breach excused, unless
such waiver is in writing signed on behalf of the party against which
the waiver is asserted. No waiver (whether express or implied) will
constitute consent to, waiver of, or excuse of any other, different, or
subsequent breach.

9.7 <span class="underline">Audits</span>. Licensee agrees that Autodesk
has the right to require an audit (electronic or otherwise) of the
Autodesk Materials and the Installation thereof and Access thereto. As
part of any such audit, Autodesk or its authorized representative will
have the right, on fifteen (15) days’ prior notice to Licensee, to
inspect Licensee’s records, systems and facilities, including machine
IDs, serial numbers and related information, to verify that the use of
any and all Autodesk Materials is in conformance with this Agreement.
Licensee will provide full cooperation to enable any such audit. If
Autodesk determines that Licensee’s use is not in conformity with the
Agreement, Licensee will obtain immediately and pay for valid license(s)
to bring Licensee’s use into compliance with this Agreement and other
applicable terms and pay the reasonable costs of the audit. In addition
to such payment rights, Autodesk reserves the right to seek any other
remedies available at law or in equity, whether under this Agreement or
otherwise.

9.8 <span class="underline">Language</span>. The English language
version of this Agreement is legally binding in case of any
inconsistencies between the English version and any translations. If
Licensee purchased the license for the Licensed Materials in Canada,
Licensee agrees to the following: The parties hereto confirm that it is
their wish that this Agreement, as well as other documents relating
hereto, including notices, have been and shall be written in the English
language only. Les parties ci-dessus confirment leur désir que cet
accord ainsi que tous les documents, y compris tous avis qui s'y
rattachent, soient rédigés en langue anglaise.

9.9 <span class="underline">Construction</span>. Ambiguities in this
Agreement will not be construed against the drafter.

9.10 <span class="underline">Force Majeure</span>. Autodesk will not be
liable for any loss, damage or penalty resulting from delays or failures
in performance resulting from acts of God, supplier delay or other
causes beyond Autodesk's reasonable control.

9.11 <span class="underline">U.S. Government Rights</span>. For U.S.
Government procurements, all Autodesk Materials are deemed to be
commercial computer software as defined in FAR 12.212 and subject to
restricted rights as defined in FAR Section 52.227-19 "Commercial
Computer Software - Restricted Rights" and DFARS 227.7202, “Rights in
Commercial Computer Software or Commercial Computer Software
Documentation”, as applicable, and any successor regulations. Any use,
modification, reproduction release, performance, display or disclosure
of the Autodesk Materials by the U.S. Government shall be solely in
accordance with license rights and restrictions described herein.

9.12 <span class="underline">Export Control</span>. Licensee
acknowledges and agrees that the Autodesk Materials and Services
(including any data submitted by Licensee in connection with a Service
and any Licensee-specific output generated by a Service) are subject to
compliance with United States and other applicable country export
control and trade sanctions laws, rules and regulations, including,
without limitation the regulations promulgated by the U.S. Department of
Commerce and the U.S. Department of the Treasury (collectively, "Export
Control Laws"). Licensee represents, warrants and covenants that neither
Licensee nor Licensee’s Personnel (i) are a citizen or resident of, or
located within, a nation that is subject to U.S. trade sanctions or
other significant trade restrictions (including, without limitation,
Cuba, Iran, Sudan, Syria and North Korea), (ii) are identified on any of
the U.S. government restricted party lists (including, without
limitation, the U.S. Treasury Department's List of Specially Designated
Nationals and Blocked Persons, the U.S. Department of Commerce’s Denied
Party List, Entity List and Unverified List and the U.S. Department of
State’s proliferation-related lists), (iii) will, unless otherwise
authorized under the Export Control Laws, use Autodesk Materials or
Services in any restricted end use, including, without limitation,
design, analysis, simulation, estimation, testing, or other activities
related to nuclear, chemical/biological weapons, rocket systems or
unmanned air vehicles applications, or (iv) will use the Autodesk
Materials or Services to disclose, transfer, download, export, or
re-export, directly or indirectly, any Licensee-specific output
generated by the Autodesk Materials or Services, Licensee content, third
party content, or any other content or material to any country, entity,
or party that is ineligible to receive such items under the Export
Control Laws or other laws or regulations to which Licensee may be
subject. Licensee understands that the requirements and restrictions of
the Export Control Laws as applicable to Licensee may vary depending on
the Autodesk Materials or Services provided under this Agreement and may
change over time. Licensee shall be solely responsible for (i)
determining the precise controls applicable to the Autodesk Materials or
Services, and (ii) complying with the Export Control Laws and monitoring
any modifications to them.

9.13 <span class="underline">Entire Agreement</span>. This Agreement and
any other terms referenced in this Agreement (such as the Relationship
Program Terms and the Services Terms) constitute the entire agreement
between the parties (and merge and supersede any prior or
contemporaneous agreements, discussions, communications, agreements,
representations, warranties, advertising or understandings) with respect
to the subject matter hereof, except that particular Autodesk Materials
may be subject to additional or different terms associated with such
Autodesk Materials. The parties acknowledge that, in entering into this
Agreement, they are not relying on any agreements, discussions,
communications, agreements, representations, warranties, advertising or
understandings other than as expressly set forth in this Agreement.
Licensee acknowledges and agrees that Autodesk may add to or change the
Relationship Program Terms and the Services Terms from time to time,
provided that Autodesk will provide written notice of the additions or
changes (and may allow Licensee not to renew, may permit Licensee to
terminate, and may offer other options with respect to Relationship
Programs or Services) before the additions or changes are effective as
to Licensee. In the event of a conflict between this Agreement and any
other terms of Autodesk (including, without limitation, the Relationship
Program Terms, the Services Terms, or such additional or different
terms), the other terms will apply. Terms stipulated by Licensee in any
communication by Licensee which purport to vary this Agreement or such
other terms will be void and of no effect unless agreed in a writing
signed by an authorized representative of Autodesk. Any other
modifications to this Agreement will also be invalid unless agreed to in
a writing signed by an authorized representative of Autodesk.

10\. **Additional Terms.**

This Section 10 (Additional Terms) applies to the following Software
that may be included within the Licensed Materials: (i) Autodesk Maya;
(ii) Autodesk Softimage; (iii) Autodesk 3ds Max; and (iv) Autodesk 3ds
Max Design.

10.1 <span class="underline">Rendering</span>.

10.1.1 With regard to the Rendering Software (defined below), in
addition to any other license granted in this Agreement, Licensee may
allow the Rendering Software to be Installed or Accessed on a Networked
Basis, solely for Licensee’s Internal Business Needs, specifically to
render files created with the Software. However, if the Rendering
Software is mental ray, and the Software is provided with a finite
number of mental ray rendering nodes, then with regard to mental ray the
foregoing is restricted to that number of mental ray rendering nodes.

10.1.2 With regard to the mental ray Batch Software (defined below), in
addition to any other license granted in this Agreement, Licensee may
allow the mental ray Batch Software to be Installed or Accessed on a
Networked Basis, solely for Licensee’s Internal Business Needs, and used
(i) specifically to render files created with the Software; or (ii) by
the Rendering Software specifically to render files created with the
Software. The total number of CPUs used by the mental ray Batch Software
cannot exceed the number specified in the License Identification.

10.1.3 With regard to the mental ray Standalone (defined below),
Licensee may allow the mental ray Standalone to be Installed or
Accessed, on a Networked Basis, solely on Computing Device(s) (defined
below) solely for Licensee’s Internal Business Needs specifically to
render files created with the Software. With regard to mental ray
Standalone, any reference in the Agreement to Computer is hereby deleted
and “Computing Device(s)” substituted therefor.

10.1.4 With regard to the mental ray Satellite (defined below) for each
of Autodesk 3ds Max, Autodesk Maya and Autodesk Softimage Software each
mental ray Satellite executable(s) may run on one (1) or more host no
more than four (4) client Computing Devices. With regard to mental ray
Satellite, any reference in the Agreement to Computer is hereby deleted
and “Computing Device(s)” substituted therefor.

10.1.5 <span class="underline">Definitions</span>.

(1) “mental ray Standalone” means the mental ray Standalone
client/server executable, including the mental ray standard shader
libraries and utility programs, used specifically for rendering files
created with the Software.

(2) “Rendering Software” means a subset of the Software used
specifically for rendering files created with the Software.

(3) “mental ray Batch Software” means a subset of the Software used: (i)
specifically for rendering files created with the Software or (ii) by
the Rendering Software specifically for rendering files created with the
Software.

(4) “mental ray Satellite” means the mental ray Satellite server
executable, including the mental ray standard shader libraries. mental
ray Satellite is functionally equivalent to the mental ray Standalone
server executable, used specifically for rendering files created with
the Software except it is not able to read and write files in the
complete mi2 format.

(5) “Computing Device” means (i) a single electronic assembly with a
maximum of: (a) four (4) CPUs (regardless of the number of cores in each
CPU) each CPU having one or more microprocessors, (b) four (4) discrete
GPU-based computing boards; or (ii) a software implementation of the
single electronic assembly, (a so-called 'virtual machine') described in
(i) above, which single electronic assembly accepts information in
digital or similar form and manipulates the information for a specific
result based on a sequence of instructions.

10.2 <span class="underline">Exceptions</span>.

10.2.1 This Section 10.2 (Exceptions) applies to the Autodesk Media &
Entertainment 3D entertainment Software that may be included within the
Licensed Materials. Notwithstanding the provisions set forth in Section
2.1.1 (No License Granted; Unauthorized Activities) if: (i) the
Redistributable Component (defined below) operates with the Software and
with Licensee Application; and (ii) the Redistributable Component is
linked to Licensee Application; then Licensee may reproduce and
distribute the Redistributable Component and Licensee Application
together, subject to Licensee’s strict adherence to all of the following
terms and conditions:

(a) the class identifications for any classes of objects Licensee
created shall be different from and clearly distinguishable from the
class identifications used by Autodesk;

(b) modified Sample (defined below) code and any resulting binary files
in Licensee Application are identified as developed by Licensee, and not
by Autodesk;

(c) Licensee Application has Licensee’s copyright notice;

(d) any Modification (defined below), and resulting binary files, shall
include the copyright notices of Autodesk, Inc. as well as the following
statement: "This software contains copyrighted code owned by Autodesk,
Inc. but has been modified and is not endorsed by Autodesk, Inc." The
language of the copyright notice and the statement shall be in the same
language as the Software language;

(e) distribution is strictly for not-for-profit purposes;

(f) distribution is either in binary form or text form;

(g) distribution is subject to a standard form of click-through end-user
license agreement which license agreement, among other things: (1)
protects Autodesk's interests consistent with the terms of this
Agreement; and (2) prohibits the redistribution of the Redistributable
Component;

(h) if the Redistributable Component operates with the Autodesk 3ds Max
Software and/or Autodesk 3ds Max Design Software and with Licensee
Application then prior to reproduction and distribution of the
Redistributable Component and Licensee Application all MIDI files have
been excluded from the Redistributable Component and Licensee
Application; and

(i) Licensee agrees to defend, indemnify and hold harmless Autodesk and
its subsidiaries and affiliates from and against any and all damages,
costs, losses, liabilities, expenses and settlement amounts incurred in
connection with any suit, claim or action by any third party alleging
that the Redistributable Component and/or Licensee Application infringes
or misappropriates any patent, copyrights, moral rights, trademark,
trade secret and design rights, whether registered or unregistered, and
including any application for registration of any of the foregoing and
all rights or forms of protections of a similar nature having equivalent
or similar effect to any of these, which may subsist anywhere in the
world, of such third party.

10.2.2 <span class="underline">Definitions</span>.

(1) "Licensee Application" means, with regard to the Software, a
Modification made by Licensee for designing, developing, and testing an
application program made by Licensee.

(2) "Modification" means any: (i) addition to the substance of a Sample
or any addition to the substance of the contents of a file containing a
Sample; (ii) any deletion from the structure of a Sample, or any
deletion from the structure of the contents of a file containing a
Sample; and/or (iii) any new file that contains any part of a Sample;
all of which, in Autodesk’s sole discretion, ensures that the Sample is
not the primary source of value.

(3) "Redistributable Component" means the Sample(s) and/or a
Modification.

(4) "Sample(s)" means sample source code, or individual animations,
still images, and/or audio files contained in the Software, and located
in the samples directory, the examples subdirectory, samples files or
any similar type directory or file.

10.3 <span class="underline">Additional Terms; Certain Softimage
Materials</span>. This Section 10.3 (Additional Terms; Certain Softimage
Materials) applies to the following Software that may be included within
the Licensed Materials: (i) Autodesk Softimage Mod Tool software; and
(ii) Autodesk Softimage Mod Tool Pro software.

10.3.1 <span class="underline">Autodesk Softimage Mod Tool
Software</span>. In the event the Software is Autodesk Softimage Mod
Tool Software then the applicable Exhibit B License Type is B. 4.
(<span class="underline">Educational Stand-alone (Individual)
License</span>).

10.3.2 <span class="underline">Autodesk Softimage Mod Tool Pro
Software</span>. In the event the Software is Autodesk Softimage Mod
Tool Pro Software, then the applicable Exhibit B License Type is B. 1.
(Stand-alone (Individual) License), however, Licensee’s Internal
Business Needs are limited to the design, development and testing of an
application program designed to function with the Software for
Licensee’s internal use in producing multimedia content in conjunction
with Licensee’s valid XNA<sup>®</sup> Creators Club Online Premium
Membership.

11\. **Additional Terms: Quantity Take Off**.

This Section 11 (Additional Terms; Quantity Take Off) applies to the
Quantity Take Off Software that may be included within the Licensed
Materials (“QTO Software”):

11.1 The QTO Software is based in part on the work of the Independent
JPEG Group.

11.2 Portions of the QTO Software include Crystal Reports Runtime
Software (“Runtime Software”) licensed from Business Objects Software
Ltd (“Business Objects”). Licensee’s use of the Runtime Software is
subject to the following terms:

(a) Licensee agrees not to alter disassemble, decompile, translate,
adapt or reverse-engineer the Runtime Software or the report file (.RPT)
format;

(b) Licensee agrees not to distribute the Runtime Software with any
general-purpose report writing, data analysis or report delivery product
or any other product that performs the same or similar functions as
Business Objects’ product offerings;

(c) Licensee agrees not to use the Runtime Software to create for
distribution a product that is generally competitive with Business
Objects' product offerings;

(d) Licensee agrees not to use the Runtime Software to create for
distribution a product that converts the report file (.RPT) format to an
alternative report file format used by any general-purpose report
writing, data analysis or report delivery product that is not the
property of Business Objects; and

(e) Licensee agrees not to use the Crystal Reports Software on a rental
or timesharing basis or to operate a service bureau facility for the
benefit of third-parties.

11.3 BUSINESS OBJECTS AND ITS SUPPLIERS DISCLAIM ALL WARRANTIES, EXPRESS
OR IMPLIED, INCLUDING WITHOUT LIMITATION THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT
OF THIRD PARTY RIGHTS. BUSINESS OBJECTS AND ITS SUPPLIERS SHALL HAVE NO
LIABILITY WHATSOEVER UNDER THIS AGREEMENT OR IN CONNECTION WITH THE
CRYSTAL REPORTS SOFTWARE.

12\. Autodesk download technology may use the Akamai NetSession
Interface, which may utilize a limited amount of your upload bandwidth
and PC resources to connect you to a peered network and improve speed
and reliability of Web content. The Akamai NetSession Interface is
secure client-side networking technology that harnesses the power of
your computer to deliver software and media available on the Akamai
network. Your Akamai NetSession Interface works collectively with other
Akamai NetSession Interfaces, along with thousands of Akamai edge
servers, and runs as a networking service utilizing a limited amount of
your computer's available resources. More information about the Akamai
NetSession Interface is available here:
[<span class="underline">http://www.akamai.com/client</span>](http://www.akamai.com/client).
By clicking "Accept" and using the Autodesk download technology, you
accept the Akamai License Agreement
([<span class="underline">http://www.akamai.com/eula</span>](http://www.akamai.com/eula))
in addition to the Autodesk License and Service Agreement.

**Exhibit A**

**<span class="underline">Definitions</span>**

1\. “<span class="underline">Access</span>” or
“<span class="underline">Accessible</span>” means, with respect to a
computer program or other materials, (a) to use or execute the computer
program or other materials or (b) to use or otherwise benefit from the
features or functionality of the computer program or other materials.

2\. “<span class="underline">Agreement</span>” means this License and
Services Agreement, including all exhibits and schedules thereto, as the
License and Services Agreement may be amended from time to time in
accordance with the terms thereof.

3\. “<span class="underline">Authorized User</span>” means any
individual person who Installs or Accesses, or is authorized to Install
or Access, any of the Licensed Materials.

4\. “<span class="underline">Autodesk</span>” means Autodesk, Inc., a
Delaware corporation, except that if, Licensee acquires a license to the
Autodesk Materials in (a) a country in Europe, Africa or the Middle
East, “Autodesk” means Autodesk Development Sàrl or (b) a country in
Asia, Oceania or the Asia-Pacific region, “Autodesk” means Autodesk Asia
Pte Ltd.

5\. “<span class="underline">Autodesk License Manager</span>” means the
tool known as Autodesk License Manager or any future Autodesk tool for
managing, monitoring or controlling Installation of or Access to
Autodesk Materials.

6\. “<span class="underline">Autodesk Materials</span>” means any
materials distributed or made available by Autodesk, directly or
indirectly, including Software, Supplemental Materials, User
Documentation and Excluded Materials (whether or not licensed to
Licensee).

7\. “<span class="underline">Computer</span>” means (i) a single
electronic device, with one or more central processing units (CPUs),
that accepts information in digital or similar form and manipulates the
information for a specific result based on a sequence of instructions,
or (ii) a software implementation of such a device (or so-called virtual
machine).

8\. “<span class="underline">Customer Information Form</span>” means a
form completed by or on behalf of Licensee and submitted to Autodesk or
a Reseller, directly or indirectly, in connection with Licensee’s order
for a license of Autodesk Materials, Relationship Program or Services.

9\. “<span class="underline">Educational Licensee</span>” means a
Licensee who is also (a) a Qualified Educational Institution, (b)
Faculty, (c) Student or (d) Other Authorized Educational Licensee. An
Educational Licensee may be required to show proof of eligibility if
requested by Autodesk. Autodesk, in its sole discretion, retains the
right to determine the eligibility of an Educational Licensee.

10\. “<span class="underline">Educational Purposes</span>” means (i) in
the case of a Qualified Educational Institution, Faculty or Other
Authorized Educational Licensees, purposes directly related to learning,
teaching, training, research and development that are part of the
instructional functions performed by a Qualified Educational Institution
or Other Authorized Educational Licensee and (ii) in the case of
Students, purposes related to learning, training, research or
development. “Educational Purposes” does not include commercial,
professional or any other for-profit purposes.

11\. “<span class="underline">Evaluation Purposes</span>” means purposes
of evaluation and demonstration of the capabilities of the Software or
Supplemental Materials but excludes competitive analysis and any
commercial, professional, or other for-profit purposes.

12\. “<span class="underline">Excluded Materials</span>” means any
materials, including Software, Supplemental Materials or User
Documentation (and including, without limitation, any computer programs,
modules or components of a computer program, functionality or features
of a computer program, explanatory printed or electronic materials,
content or other materials, if any), that may be provided or become
available to Licensee, by any means, or that are on any media delivered
to Licensee, for which (a) Licensee does not have a License
Identification, or (b) Licensee has not paid (and continued to pay) the
applicable fees. Licensee acknowledges that Excluded Materials are
included on media or via download for convenience of the licensing
mechanism used by Autodesk, and inclusion does not in any way authorize,
expressly or impliedly, a right to use such Excluded Materials.

13\. “<span class="underline">Faculty</span>” means an individual person
who is an employee or independent contractor working for a Qualified
Educational Institution.

14\. “<span class="underline">Install</span>” and
“<span class="underline">Installation</span>” means, with respect to a
computer program or other materials, to copy the program or other
materials onto a hard disk or other storage medium.

15\. “<span class="underline">License Identification</span>” means one
or more designations by Autodesk that set forth the License Type (among
other things) for Licensee’s license of the Licensed Materials. The
License Identification may be (a) located (i) in the Licensed Materials
(e.g., in an “About” box, license information dialog box, or text file
of Software), (ii) on or with Autodesk packaging, or (iii) in a written
confirmation or other notice issued to Licensee by Autodesk and
transmitted via email, facsimile, physical delivery, or otherwise, or
(b) obtained from Autodesk on request. For clarification, License
Identification does not include a designation, confirmation, packaging
or other document provided by a Reseller or other third party.

16\. “<span class="underline">License Type</span>” means a type of
license specified by Autodesk for Autodesk Materials, including the
types set forth in Exhibit B. License Type includes the terms specified
by Autodesk for each type of license, including the applicable terms set
forth in Exhibit B. License Type is determined by Autodesk and may be
specified in the applicable License Identification.

17\. “<span class="underline">Licensed Materials</span>” means Software,
Supplemental Materials and User Documentation (a) downloaded by clicking
on the “I accept” button or other button or mechanism associated with
this Agreement or by otherwise indicating assent to this Agreement, (b)
delivered prepackaged with this Agreement, or (c) otherwise accompanied
by this Agreement, provided that (i) in the case of Software, the
Software is identified in an applicable License Identification, and (ii)
Licensee has paid (and continues to pay) the applicable fees. Licensed
Materials also includes Supplemental Materials and User Documentation
that Autodesk provides or makes available to Licensee for use with
Software licensed under this Agreement if there are no separate terms
for such materials specified by Autodesk. Licensed Materials includes,
without limitation, any error corrections, patches, service packs,
updates and upgrades to, and new versions of, the Licensed Materials
that Autodesk provides or makes available to Licensee under Licensee’s
then-current license. Licensee acknowledges that availability of
Upgrades and new versions may be subject to additional fees and the
Relationship Program Terms. In addition, Licensed Materials includes,
without limitation, any Previous Versions and other Autodesk Materials
that Licensee receives or retains pursuant to the Relationship Program
Terms, but only for so long as and to the extent expressly authorized by
the Relationship Program Terms. Notwithstanding the foregoing (or any
other provision of this Agreement), Licensed Materials in all cases
excludes Excluded Materials.

18\. “<span class="underline">Licensee</span>” means (a) the company or
other legal entity on behalf of which Autodesk Materials are acquired,
if the Autodesk Materials are acquired on behalf of such an entity
(e.g., by an employee, independent contractor, or other authorized
representative), or (b) if there is no such entity, the individual who
accepts this Agreement (e.g., by selecting the “I accept” button or
other button or mechanism associated with this Agreement or otherwise
indicating assent to this Agreement, or by installing, downloading,
accessing, or otherwise copying or using all or any portion of the
Autodesk Materials). For clarification, “Licensee” refers only to a
single, specifically identified legal entity or individual, and does not
include any subsidiary or affiliate of any such legal entity or
individual or any other related person.

19\. “<span class="underline">Licensee’s Internal Business Needs</span>”
means, in reference to Licensed Materials, the use of such Licensed
Materials (and the features and functionality thereof) by Licensee’s own
Personnel to meet the internal requirements of Licensee’s business in
the ordinary course of such business, provided that Internal Business
Needs will in no event include providing or making available such
Licensed Materials (or the features or functionality thereof) to any
third party.

20\. “<span class="underline">Networked Basis</span>” means a computing
environment that includes a Computer acting as a file server which
allows the Licensed Materials Installed on such Computer to be uploaded
and Installed to, and operated, viewed or otherwise Accessed from, other
Computers through a local area network connection or through a VPN
connection subject to compliance with the VPN Requirements.

21\. “<span class="underline">Open Source</span>” means any software
code that: (a) contains, or is derived in any manner, (in whole or in
part), from any software that is distributed as free software, open
source software, shareware (e.g., Linux), or similar licensing or
distribution models; and (b) is subject to any agreement with terms
requiring that using, copying, modifying or redistributing the software
requires that such software and/or the derivative works of such software
be: (i) disclosed and/or distributed in source code form; (ii) be
licensed for the purpose of making derivative works; and/or (iii) be
redistributed free of charge; including, without limitation, software
licensed or distributed under any of the following licenses or
distribution models, or licenses or distribution models similar to,
GNU’s General Public License (GPL) or Lesser/Library GPL (LGPL).

22\. “<span class="underline">Other Authorized Educational
Licensee</span>” means a Licensee described at
[<span class="underline">http://www.autodesk.com/educationterms</span>](http://www.autodesk.com/educationterms)
or as otherwise authorized in writing by Autodesk.

23\. “<span class="underline">Permitted Number</span>” means a maximum
number (e.g., number of authorized users, number of concurrent users,
number of computers, sessions, etc.) applicable to a license of the
Licensed Materials and to the License Type associated with such license.
Such number is determined by Autodesk and may be specified in the
applicable License Identification.

24\. “<span class="underline">Personal Learning Purposes</span>” means
(i) personal learning as a Student or (ii) in the case of a non-Student,
personal learning, excluding (a) in-person or online classroom learning
in any degree-granting or certificate granting program, and (b) learning
related to any commercial, professional or other for-profit purposes.

25\. “<span class="underline">Personnel</span>” means (a) Licensee’s
individual employees and (b) individual persons who are independent
contractors working on Licensee’s premises and who Install and Access
the Licensed Materials only on and through Computers owned or leased and
controlled by Licensee.

26\. “<span class="underline">Previous Versions</span>” means, as to any
then-current release of Licensed Materials, a prior release of the
Licensed Materials as to which such then-current release is a successor
or substitute (as determined by Autodesk).

27\. “<span class="underline">Qualified Educational Institution</span>”
means an educational institution which has been accredited by an
authorized governmental agency within its applicable local, state,
provincial, federal, or national government and has the primary purpose
of teaching its enrolled students. Examples, without limitation, of
entities that are included and excluded from this definition are
described at
[<span class="underline">http://www.autodesk.com/educationterms</span>](http://www.autodesk.com/educationterms).

28\. “<span class="underline">Relationship Program</span>” means (i)
Subscription or (ii) a rental program offered generally by Autodesk
pursuant to which Autodesk makes available Licensed Materials.

29\. “<span class="underline">Relationship Program Terms</span>” means
the terms for a Relationship Program set forth at
[<span class="underline">http://usa.autodesk.com/company/legal-notices-trademarks/support-terms-and-conditions</span>](http://usa.autodesk.com/company/legal-notices-trademarks/support-terms-and-conditions)
or any successor or supplemental web page of Autodesk (the URL for which
may be obtained on Autodesk’s website or on request).

30\. “<span class="underline">Reseller</span>” means a distributor or
reseller authorized directly or indirectly by Autodesk to distribute
authentic Autodesk Materials to Licensee.

31\. ”<span class="underline">Services</span>” means services (including
the results of services) provided or made available by Autodesk,
including, without limitation, support services, storage, simulation and
testing services, training and other benefits, but excluding services
provided or made available as part of a Relationship Program.

32\. “<span class="underline">Services Terms</span>” means the terms for
Services set forth at a location where a user may order or register for,
or that is displayed in connection with ordering or registering for,
such Services (e.g., a web page) or, if there are no such terms, at
[<span class="underline">http://usa.autodesk.com/company/legal-notices-trademarks/terms-of-service</span>](http://usa.autodesk.com/company/legal-notices-trademarks/terms-of-service)
(if the Services are web services) or
[<span class="underline">http://usa.autodesk.com/company/legal-notices-trademarks/terms-of-use</span>](http://usa.autodesk.com/company/legal-notices-trademarks/terms-of-use)
for all other Services) or any successor or supplemental web pages of
Autodesk.

33\. “<span class="underline">Software</span>” means the Autodesk FBX
SDK computer program, or a module or component of a computer program,
including the software development kit (“SDK”) distributed or made
available by Autodesk. The term “Software” may also refer to functions
and features of a computer program.

34\. “<span class="underline">Stand-alone Basis</span>” means (i) the
Licensed Materials are Installed on a single Computer and (ii) the
Licensed Materials cannot be Installed on, or operated, viewed or
otherwise Accessed from or through any other Computer (e.g., through a
network connection of any kind).

35\. “<span class="underline">Student</span>” means an individual person
enrolled as a student at a Qualified Educational Institution.

36\. “<span class="underline">Subscription</span>” is the program
offered generally by Autodesk under which Autodesk provides (among other
things) updates and upgrades to, new versions of, and certain other
support, services and training relating to Autodesk Materials.

37\. “<span class="underline">Supplemental Materials</span>” means
materials, other than Software and related User Documentation, that are
distributed or made available by Autodesk for use with Software.
Supplemental Materials include, without limitation, (a) content, such as
sample drawings and designs, modules for drawings and designs, and
representations of elements used in drawings and designs (e.g.,
buildings, parts of buildings, fixtures, furniture, bridges, roads,
characters, backgrounds, settings and animations), (b) background
materials, such as building codes and descriptions of building
practices, (c) tools for rendering the output of the Software, such as
fonts, and (d) Development Materials, application programming interfaces
(APIs), and other similar developer materials (including API
Information).

37 “<span class="underline">Territory</span>” (a) means the country,
countries or jurisdiction(s) specified in the License Identification, or
(b) if there is no such License Identification, or no country or
jurisdiction is specified in the License Identification, means the
country in which Licensee acquires a license to the Autodesk Materials.
If the License Identification specifies, or Licensee acquires the
Autodesk Materials in, a member country of the European Union or the
European Free Trade Association, Territory means all the countries of
the European Union and the European Free Trade Association.

38\. “<span class="underline">Uninstall</span>” means to remove or
disable a copy of Autodesk Materials from a hard drive or other storage
medium through any means or otherwise to destroy or make unusable a copy
of the Autodesk Materials.

39\. “<span class="underline">Upgrade</span>” means a full commercial
version of Licensed Materials (a) which is a successor to or substitute
for a qualifying prior release (and may incorporate error corrections,
patches, service packs and updates and upgrades to, and may enhance or
add to the features or functionality of, the prior release) or different
release of Licensed Materials, (b) is provided to a Licensee who has
previously licensed the applicable qualifying prior or different release
from Autodesk and (c) for which Autodesk generally charges a separate
fee or makes available solely to customers under a Relationship Program.
Whether Autodesk Materials are an Upgrade may be specified in the
applicable License Identification. Whether Autodesk Materials are an
Upgrade and whether Licensee has met the qualifications to license
particular Autodesk Materials as an Upgrade are determined by Autodesk.

40\. “<span class="underline">User Documentation</span>” means the
explanatory or instructional materials for Software or Supplemental
Materials (including materials regarding use of the Software or
Supplemental Materials), whether in printed or electronic form, that
Autodesk or a Reseller incorporates in the Software or Supplemental
Materials (or the packaging for the Software or Supplemental Materials)
or otherwise provides to its customers when or after such customers
license, acquire or Install the Software or Supplemental Materials.

41\. “<span class="underline">VPN Requirements</span>” means (i) the
Licensed Materials are Accessed through a secure virtual private network
(“VPN”); (ii) the maximum number of concurrent users Accessing the
Licensed Materials (on a Networked Basis or through the VPN) does not
exceed the Permitted Number at any time; (iii) all copies of the
Licensed Materials are Installed and Accessed exclusively in conjunction
with the technical protection device (if any) supplied with the Licensed
Materials; and (iv) the VPN connection is secure and complies with
current industry standard encryption and protection mechanisms.

**Exhibit B**

**<span class="underline">License Types</span>**

1\. <span class="underline">Stand-alone (Individual) License</span>. If
the License Identification identifies the License Type as a “Stand-alone
License” or as an “Individual License," Licensee may Install a single
primary copy of the specific release of the Licensed Materials
designated in the applicable License Identification on one (1) Computer,
on a Stand-alone Basis, and permit Access to such primary copy of the
Licensed Materials solely by Licensee’s Personnel, and solely for
Licensee’s Internal Business Needs. Licensee may also Install a single
additional copy of such Licensed Materials on one (1) additional
Computer, on a Stand-alone Basis; provided that (i) such additional copy
of the Licensed Materials is Accessed solely by the same person as the
primary copy; (ii) such person is Licensee (if Licensee is an
individual) or an employee of Licensee; (iii) such person Accesses the
additional copy solely to perform work while away from that person’s
usual work location and solely for Licensee’s Internal Business Needs;
and (iv) the primary and additional copies are not Accessed at the same
time. Stand-alone (Individual) License is for a perpetual term, except
as otherwise provided in this Agreement.

2\. <span class="underline">Multi-seat Stand-alone License</span>. If
the License Identification identifies the License Type as a “Multi-seat
Stand-alone License," Licensee may Install primary copies of the
specific release of the Licensed Materials designated in the applicable
License Identification on up to the Permitted Number of Computers, on a
Stand-alone Basis, and permit Access to such copies of the Licensed
Materials solely by Licensee’s Personnel, and solely for Licensee’s
Internal Business Needs. Licensee may also Install additional copies of
such Licensed Materials on additional Computers in an amount up to the
Permitted Number of Computers, on a Stand-alone Basis; provided that (i)
each additional copy of such Licensed Materials is Accessed solely by
the same person as the primary copy; (ii) such person is Licensee (if
Licensee is an individual) or an employee of Licensee; (iii) such person
Accesses the additional copy solely to perform work while away from that
person’s usual work location and solely for Licensee’s Internal Business
Needs; and (iv) the primary and additional copies are not Accessed at
the same time. Multi-seat Stand-alone License is for a perpetual term,
except as otherwise provided in this Agreement.

3\. <span class="underline">Network License</span>. If the License
Identification identifies the License Type for the Licensed Materials as
a “Network License," Licensee may Install copies of the specific release
of the Licensed Materials designated in the applicable License
Identification on a Computer and permit Access to such Licensed
Materials on multiple Computers, on a Networked Basis, solely by
Licensee’s Personnel, solely for Licensee’s Internal Business Needs,
only so long as the maximum number of concurrent Authorized Users does
not exceed the Permitted Number of Authorized Users or other limits
imposed by the Autodesk License Manager (if any). Licensee may, at
Licensee’s option, also Install the Licensed Materials on a Hot Backup
Server; provided that Licensee may Access the Licensed Materials on the
Hot Backup Server only during the time period when, and solely for as
long as, the primary Installed copy of the Licensed Materials is
inoperable and only subject to the same terms and conditions as are
applicable to the primary Installed copy. A “Hot Backup Server” means a
file server Computer that has a second copy of the Software and
Supplemental Materials Installed but that is not permitted to be
Accessible except when the primary Installed copy of the Software and
Supplemental Materials are inoperable and only for so long as such
primary Installed copy is inoperable. A Network License is for a
perpetual term, except as otherwise provided in this Agreement.

4\. <span class="underline">Educational Stand-alone (Individual)
License</span>.  If the License Identification identifies the License
Type as an “Educational Stand-alone (Individual) License,” an
Educational Licensee may Install a copy of the specific release of the
Licensed Materials designated in the applicable License Identification
on one (1) Computer, subject to certain functional limitations described
in Section 6.3 (Affected Data), on a Stand-alone Basis, and permit
Access to such copy of the Licensed Materials solely by an Educational
Licensee solely for Educational Purposes.  An Educational Stand-alone
(Individual) License is for a fixed term specified in the applicable
License Identification or, if no such term is specified, the term is
thirty-six (36) months from Installation or as otherwise authorized in
writing by Autodesk.

5\. <span class="underline">Educational Multi-seat Stand-alone
License</span>. If the License Identification identifies the License
Type as an “Educational Multi-seat Stand-alone License,” an Educational
Licensee may Install copies of the specific release of the Licensed
Materials designated in the applicable License Identification on up to
the Permitted Number of Computers, subject to certain functional
limitations described in Section 6.3 (Affected Data), on a Stand-alone
Basis, and permit Access to such copies of the Licensed Materials solely
by Educational Licensees solely for Educational Purposes. An Educational
Multi-seat Stand-alone License is for a fixed term specified in the
applicable License Identification or, if no such term is specified, the
term is thirty-six (36) months from Installation or as otherwise
authorized in writing by Autodesk.

6\. <span class="underline">Educational Network License</span>. If the
License Identification identifies the License Type as an “Educational
Network License,” an Educational Licensee may Install copies of the
specific release of the Licensed Materials designated in the applicable
License Identification on a single file server Computer, subject to
certain functional limitations described in Section 6.3 (Affected Data),
and Access such Licensed Materials on multiple Computers on a Networked
Basis, and permit Access to such copies of the Licensed Materials solely
by Educational Licensees solely for Educational Purposes, only so long
as the maximum number of concurrent Authorized Users does not exceed the
Permitted Number of Authorized Users. An Educational Network License is
for a fixed term specified in the applicable License Identification or,
if no such term is specified, the term is thirty-six (36) months from
Installation or as otherwise authorized in writing by Autodesk.

7\. <span class="underline">Personal Learning License</span>. If the
License Identification identifies the License Type as a “Personal
Learning License”, Licensee may Install a copy of the specific release
of the Licensed Materials designated in the applicable License
Identification on one (1) Computer, subject to certain functional
limitations described in Section 6.3 (Affected Data), on a Stand-alone
Basis, and permit Access to such copy of the Licensed Materials solely
by Licensee, as an individual, solely for Personal Learning Purposes and
only at and from locations that are not labs or classrooms and are not
operated for commercial, professional or for-profit purposes. A Personal
Learning License Stand-alone is for a fixed term specified in the
applicable License Identification. If no such term is specified, the
term is thirteen (13) months from Installation.

8\. <span class="underline">Evaluation/Demonstration/Trial</span>. If
Autodesk identifies the License Type as a “demonstration”, “evaluation”,
“trial,” “not for resale” or “NFR” version (each, an “Evaluation
License”) in the applicable License Identification, Licensee may
Install a copy of the specific release of the Licensed Materials
designated in the applicable License Identification on one (1) Computer,
subject to certain functional limitations described in Section 6.3
(Affected Data), on a Stand-alone Basis, and permit Access to such copy
of the Licensed Materials, solely by Licensee’s Personnel, solely for
Evaluation Purposes, only so long as the maximum number of concurrent
Authorized Users does not exceed one (1), and only from Licensee’s work
location. An Evaluation License is for a fixed term specified in the
applicable License Identification, or if no such term is specified, the
term is thirty (30) days from Installation or as otherwise authorized in
writing by Autodesk.

9\. <span class="underline">Fixed Term/Limited Duration/Rental
License</span>. If Autodesk identifies a license in the applicable
License Identification as being for a specified period or limited
duration or as having a fixed term or as a rental license, Licensee’s
right to Install and Access the Licensed Materials will continue only
for the period, duration or term specified in the License
Identification. Such Installation and Access will be in accordance with
and subject to the applicable License Type and Permitted Number. If
Autodesk identifies a license in the applicable License Identification
as being for a specified period or limited duration, or as having a
fixed term, or a rental license but no period, duration or term is
specified in the License Identification, the period, duration or term
will be ninety (90) days from Installation (or the period specified in
Sections B.6 (Educational Network License), B.7 (Personal Learning
License) or B.8 (Evaluation/Demonstration/Trial) of this Exhibit B with
respect to the licenses described in those sections).

10\. <span class="underline">Session Specific Network License</span>. If
the License Identification identifies the License Type as a "Session
Specific Network License", Licensee may install one (1) copy of the
specific release of the Licensed Materials designated in the applicable
License Identification on a Computer and permit Access to such Licensed
Materials from multiple Computers through a Supported Virtualization
Application, on a Networked Basis, solely by Licensee's Personnel,
solely for Licensee's Internal Business needs, only so long as the
maximum number of concurrent Sessions does not exceed the Permitted
Number or other limits imposed by the Autodesk License Manager tool (if
any). For purposes of this Session Specific Network License, (a) a
“Session” is defined as a single interactive information exchange
between two Computers that are connected through a Supported
Virtualization Application, and (b) “Supported Virtualization
Application(s)” are those third party virtualization applications or
methods that are specifically identified as supported by Autodesk in the
User Documentation for the Licensed Materials. With respect to the
applicable Supported Virtualization Application, Licensee agrees to
activate any available session tracking mechanism, not disable any such
session tracking mechanism and to retain all records generated by such
session tracking mechanism. A Session Specific Network License is for a
perpetual term, except as otherwise provided in this Agreement.
